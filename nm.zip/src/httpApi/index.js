import FakeHttpApi from "./fakeHttpApi";

export { FakeHttpApi };
