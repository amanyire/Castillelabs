import SearchContacts from "./SearchContacts";
import * as actions from "./actions";
import reducer from "./reducer";

export default SearchContacts;
export { actions, reducer };