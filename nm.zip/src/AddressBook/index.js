import AddressBook from "./AddressBook";
import reducer from "./reducer";

export default AddressBook;
export { reducer };